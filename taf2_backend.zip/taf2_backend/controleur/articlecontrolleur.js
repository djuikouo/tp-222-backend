let articles_db = [
    { 
        id: 1, 
        titre: "Introduction au web", 
        auteur: "Charles",
        date: "2026-03-18",
        categorie: "Technologie"
    },
    { 
        id: 2, 
        titre: "Apprendre Node.js", 
        auteur: "Alice",
        date: "2026-03-17",
        categorie: "Développement"
    }
];

exports.listeArticles = (req, res) => {
    res.status(200).json({
        articles: articles_db
    });
};

exports.creerArticle = (req, res) => {
    console.log("--- TENTATIVE DE CRÉATION ---");
    console.log("Données reçues (body) :", req.body);

    const { titre, contenu, auteur, categorie } = req.body;
    
    const nouvelArticle = {
        id: articles_db.length > 0 ? articles_db[articles_db.length - 1].id + 1 : 1,
        titre,
        contenu,
        auteur,
        date: new Date().toISOString().split('T')[0],
        categorie
    };

    articles_db.push(nouvelArticle);
    
    console.log("Article ajouté ! Nouvel ID :", nouvelArticle.id);
    console.log("Nombre total d'articles maintenant :", articles_db.length);

    res.status(201).json(nouvelArticle);
};
exports.voirArticle = (req, res) => {
    const id = parseInt(req.params.id);
    const article = articles_db.find(a => a.id === id);
    if (article) res.status(200).json(article);
    else res.status(404).json({ error: "Article non trouvé" });
};

exports.modifierArticle = (req, res) => {
    const id = parseInt(req.params.id);
    const index = articles_db.findIndex(a => a.id === id);

    if (index !== -1) {
        articles_db[index] = { ...articles_db[index], ...req.body };
        res.status(200).json({ message: "Article mis à jour", article: articles_db[index] });
    } else {
        res.status(404).json({ error: "Article non trouvé" });
    }
};

exports.supprimerArticle = (req, res) => {
    const id = parseInt(req.params.id);
    const lengthAvant = articles_db.length;
    articles_db = articles_db.filter(a => a.id !== id);

    if (articles_db.length < lengthAvant) {
        res.status(200).json({ message: "Article supprimé avec succès" });
    } else {
        res.status(404).json({ error: "Article non trouvé" });
    }
};

exports.rechercherArticle = (req, res) => {
    const { categorie, auteur, query } = req.query;

    let resultats = articles_db.filter(article => {
        const matchCategorie = !categorie || (article.categorie && article.categorie.toLowerCase().includes(categorie.toLowerCase()));
        const matchAuteur = !auteur || (article.auteur && article.auteur.toLowerCase().includes(auteur.toLowerCase()));
        const matchQuery = !query || (article.titre && article.titre.toLowerCase().includes(query.toLowerCase()));

        return matchCategorie && matchAuteur && matchQuery;
    });

    res.status(200).json({
        success: true,
        count: resultats.length,
        articles: resultats
    });
};
