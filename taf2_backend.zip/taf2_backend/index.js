const express = require('express');
const app = express();
const swaggerUi = require('swagger-ui-express'); 

const articleRoutes = require('./route/articleroute');

app.use(express.json());

const swaggerDocument = {
  "openapi": "3.0.0",
  "info": {
    "title": "API Blog ENSP - TAF 1",
    "description": "Documentation complète pour la gestion des articles (CRUD)",
    "version": "1.0.0"
  },
  "servers": [
    { "url": "http://localhost:3000", "description": "Serveur Local" }
  ],
  "paths": {
    "/api/articles": {
      "get": {
        "summary": "Lister tous les articles",
        "responses": { "200": { "description": "Tableau JSON des articles" } }
      },
      "post": {
        "summary": "Créer un article",
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "titre": { "type": "string" },
                  "contenu": { "type": "string" },
                  "auteur": { "type": "string" },
                  "categorie": { "type": "string" }
                }
              }
            }
          }
        },
        "responses": { "201": { "description": "Article créé avec succès" } }
      }
    },
    "/api/articles/{id}": {
      "get": {
        "summary": "Voir un article par son ID",
        "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "integer" } }],
        "responses": { "200": { "description": "Détails de l'article" } }
      },
      "put": {
        "summary": "Modifier un article",
        "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "integer" } }],
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "titre": { "type": "string" },
                  "contenu": { "type": "string" }
                }
              }
            }
          }
        },
        "responses": { "200": { "description": "Article mis à jour" } }
      },
      "delete": {
        "summary": "Supprimer un article",
        "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "integer" } }],
        "responses": { "200": { "description": "Article supprimé" } }
      }
    },
    "/api/articles/search": {
      "get": {
        "summary": "Rechercher des articles",
        "parameters": [
          { "name": "categorie", "in": "query", "schema": { "type": "string" } },
          { "name": "auteur", "in": "query", "schema": { "type": "string" } },
          { "name": "query", "in": "query", "schema": { "type": "string" }, "description": "Mot-clé dans le titre" }
        ],
        "responses": { "200": { "description": "Résultats filtrés" } }
      }
    }
  }
};

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.use('/api', articleRoutes);

app.listen(3000, () => {
  console.log(' Serveur démarré sur http://localhost:3000');
  console.log(' Documentation disponible sur http://localhost:3000/api-docs');
});
