const express = require('express');
const router = express.Router();
const articleCtrl = require('../controleur/articlecontrolleur');


router.get('/articles', articleCtrl.listeArticles);
router.get('/articles/search', articleCtrl.rechercherArticle);
router.get('/articles/:id', articleCtrl.voirArticle);
router.put('/articles/:id', articleCtrl.modifierArticle);
router.delete('/articles/:id', articleCtrl.supprimerArticle);
router.post('/articles', articleCtrl.creerArticle);

module.exports = router;
